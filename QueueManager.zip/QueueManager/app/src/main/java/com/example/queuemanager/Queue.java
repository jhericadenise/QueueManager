package com.example.queuemanager;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.queuemanager.dbutility.DBUtility;
import com.example.queuemanager.security.Security;
import com.example.queuemanager.session.QueueSession;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Queue extends AppCompatActivity implements DBUtility {

    private TextView qname;
    private QueueSession qs;

    private Button beginbutton;
    private Button endbutton;
    private Button callnextpatient;

    ProgressDialog progressDialog; //
    ConnectionClass connectionClass; //

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_queue);

        connectionClass=new ConnectionClass();//
        progressDialog=new ProgressDialog(this);//

        qs=new QueueSession(getApplicationContext());

        qname = (TextView)findViewById(R.id.queueName);
        String queuename=qs.getdoctorfirstname()+" "+qs.getdoctorlastname();
        qname.setText(queuename);

        beginbutton = (Button)findViewById(R.id.beginQueue);
        endbutton= (Button)findViewById(R.id.endQueue);
        callnextpatient= (Button)findViewById(R.id.callNextPatient);

        beginbutton.setOnClickListener(new View.OnClickListener() {//
            @Override
            public void onClick(View v) {
//                BeginQueue beginqueue=new BeginQueue();
//                beginqueue.execute();
            }
        });

    }

//
//    private class BeginQueue extends AsyncTask<String,String,String> {
//
//        String z="";
//        boolean isSuccess=false;
//
//
//        @Override
//        protected void onPreExecute() {
//
//
//            progressDialog.setMessage("Loading...");
//            progressDialog.show();
//
//
//            super.onPreExecute();
//        }
//
//        @Override
//        protected String doInBackground(String... params) {
//            try {
//                Connection con = connectionClass.CONN();
//                Security sec =new Security();
//                if (con == null) {
//                    z = "Please check your internet connection";
//                } else {
//
//                    String query=SELECT_QUEUE;
//
//                    PreparedStatement ps = con.prepareStatement(query);
//                    ps.setString(1, qs.getdoctorid());
//                    ps.setString(2, qs.getdepartmentid());
//                    // stmt.executeUpdate(query);
//
//
//                    ResultSet rs=ps.executeQuery();
//
//                    while (rs.next())
//                    {
//                        qmid=rs.getString(1);
//                        clinicid=rs.getString(2);
//                        un=rs.getString(3);
//                        fn=rs.getString(4);
//                        ln=rs.getString(5);
//                        e=rs.getString(6);
//                        isSuccess=true;
//                        z = "Login successfull";
//
//                        session.setqueuemanagerid(qmid);
//                        session.setclinicid(clinicid);
//                        session.setusername(un);
//                        session.setfirstname(fn);
//                        session.setlastname(ln);
//                        session.setemail(e);
//
//                    }
//
//
//
//                }
//            }
//            catch (Exception ex) {
//                isSuccess = false;
//                z = "Exceptions" + ex;
//            }
//            return z;
//        }
//
//        @Override
//        protected void onPostExecute(String s) {
//            Toast.makeText(getBaseContext(),""+z,Toast.LENGTH_LONG).show();
//
//            progressDialog.dismiss();
//            if(isSuccess) {
//
//                Intent intent=new Intent(MainActivity.this,Dashboard.class);
//
//                // intent.putExtra("name",usernam);
//
//                startActivity(intent);
//                finish();
//            }
//
//
//
//
//        }
}
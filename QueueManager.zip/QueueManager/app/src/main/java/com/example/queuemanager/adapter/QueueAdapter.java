package com.example.queuemanager.adapter;

public class QueueAdapter {
}
